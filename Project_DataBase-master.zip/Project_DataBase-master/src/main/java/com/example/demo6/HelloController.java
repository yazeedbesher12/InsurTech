package com.example.demo6;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javax.swing.*;
import javax.swing.text.html.ImageView;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.Objects;

public class HelloController {
    private Stage stage;
    private Scene scene;
    private Parent root;



//    @FXML
//    private TextField t1;
//    @FXML
//    private ImageView IMAGE;
//    @FXML
//    private AnchorPane sccrolpane;
//    @FXML
//    private Pane signinpanel;
//    @FXML
//    private Button HomeButton;
//    @FXML
//    private Button LoginButton;
//    @FXML
//    private Button SignUpButton;
//    @FXML
//    private Button VButton;
//    @FXML
//    private Button ACC_INV_Button;
//    @FXML
//    private Button SUP_Button;








//    @FXML
//    public void Vehicle_insurance(javafx.event.ActionEvent event) throws IOException {
//        root = FXMLLoader.load(getClass().getResource("Vehicle-insurance-registration.fxml"));
//        stage =(Stage)((Node)event.getSource()).getScene().getWindow();
//        scene = new Scene(root);
//        stage.setScene(scene);
//        stage.show();
//    }
//Parent root=
}