package com.example.demo6;

public class VehicleInsuranceController {
    }
